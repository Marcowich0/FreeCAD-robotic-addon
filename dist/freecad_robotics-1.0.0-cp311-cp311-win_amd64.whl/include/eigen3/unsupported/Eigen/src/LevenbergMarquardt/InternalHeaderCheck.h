#ifndef EIGEN_LEVENBERGMARQUARDT_MODULE_H
#error \
    "Please include unsupported/Eigen/LevenbergMarquardt instead of including headers inside the src directory directly."
#endif
