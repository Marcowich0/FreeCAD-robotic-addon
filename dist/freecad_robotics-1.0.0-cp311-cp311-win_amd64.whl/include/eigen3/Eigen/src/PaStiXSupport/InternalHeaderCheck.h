#ifndef EIGEN_PASTIXSUPPORT_MODULE_H
#error "Please include Eigen/PaStiXSupport instead of including headers inside the src directory directly."
#endif
